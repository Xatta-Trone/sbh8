{{ dd($row)}}
<img src="{{ url('uploads/'. $row->image) }}" alt="">
